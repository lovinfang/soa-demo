package com.dongnao.jack.test.service;

public class Test2ServiceImpl implements Test2Service {

	public void sleep() {
		System.out.println("Test2ServiceImpl sleep");

	}

}
