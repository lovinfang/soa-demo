package com.dongnao.jack.test.service;

public interface Test2Service {
	public void sleep();
}
