package com.dongnao.jack.test;

public interface UserService {
    public String eat(String param);
}
