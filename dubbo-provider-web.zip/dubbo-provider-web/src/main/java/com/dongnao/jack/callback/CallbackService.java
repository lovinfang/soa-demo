package com.dongnao.jack.callback;

public interface CallbackService {
    
    void addListener(String key, CallbackListener listener);
    
}
