package com.dongnao.jack.mock;

public interface MockService {
    String mock(String param);
}
