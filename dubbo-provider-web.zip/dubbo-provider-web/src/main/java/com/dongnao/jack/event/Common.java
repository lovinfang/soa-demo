package com.dongnao.jack.event;

public interface Common {
    public String eat(String param);
}
