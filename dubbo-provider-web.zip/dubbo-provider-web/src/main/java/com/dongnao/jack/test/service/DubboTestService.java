package com.dongnao.jack.test.service;

public interface DubboTestService {
    public String eat(String param);
}
