package com.dongnao.jack.frameworkservice;

public interface FrameworkTestService {
    public String sleep(String param);
}
