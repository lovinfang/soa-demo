package com.dongnao.jack.service;

public interface AnnotationDubboTest {
    public String eat(String param);
}
