package com.dongnao.jack.service;

public interface CacheService {
    
    String findCache(String id);
    
}
