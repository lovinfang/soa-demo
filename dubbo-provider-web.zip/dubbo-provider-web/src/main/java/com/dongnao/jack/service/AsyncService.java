package com.dongnao.jack.service;

public interface AsyncService {
    
    String sayHello(String name);
    
}
