package com.dongnao.jack.breakpointservice;

public class BreakpointServiceImpl implements BreakpointService {
    
    public String breakpoint(String param) {
        System.out.println("BreakpointServiceImpl breakpoint");
        return "BreakpointServiceImpl breakpoint";
    }
    
}
