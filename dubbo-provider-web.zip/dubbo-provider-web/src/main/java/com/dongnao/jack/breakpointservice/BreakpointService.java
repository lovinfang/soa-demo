package com.dongnao.jack.breakpointservice;

public interface BreakpointService {
    String breakpoint(String param);
}
