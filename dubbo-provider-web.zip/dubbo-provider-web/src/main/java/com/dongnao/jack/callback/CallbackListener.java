package com.dongnao.jack.callback;

public interface CallbackListener {
    
    void changed(String msg);
    
}
