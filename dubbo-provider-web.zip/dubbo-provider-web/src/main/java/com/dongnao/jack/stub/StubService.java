package com.dongnao.jack.stub;

public interface StubService {
    String stub(String param);
}
