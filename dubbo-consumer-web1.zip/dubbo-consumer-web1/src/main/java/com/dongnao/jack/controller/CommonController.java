package com.dongnao.jack.controller;

import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.rpc.RpcContext;
import com.alibaba.dubbo.rpc.RpcException;
import com.alibaba.dubbo.rpc.service.EchoService;
import com.alibaba.dubbo.rpc.service.GenericService;
import com.dongnao.jack.callback.CallbackListener;
import com.dongnao.jack.callback.CallbackService;
import com.dongnao.jack.event.Common;
import com.dongnao.jack.mock.MockService;
import com.dongnao.jack.service.AnnotationDubboTest;
import com.dongnao.jack.service.AsyncService;
import com.dongnao.jack.service.CacheService;
import com.dongnao.jack.service.ProviderService;
import com.dongnao.jack.service.UserService;
import com.dongnao.jack.service.ValidationParameter;
import com.dongnao.jack.service.ValidationService;
import com.dongnao.jack.stub.StubService;
import com.dongnao.jack.test.service.DubboTestService;

@Controller
@RequestMapping("/common")
public class CommonController implements ApplicationContextAware {
    
    private static Logger logger = Logger.getLogger(CommonController.class);
    
    @Reference(version = "1.0.2", check = false, group = "user1")
    UserService usrService;
    
    @Reference(version = "1.0.2", check = false, group = "user2")
    UserService usr2Service;
    
    @Autowired
    UserService user;
    
    @Autowired
    @Qualifier("mergeUserService")
    ProviderService providerService;
    
    ApplicationContext applicationContext;
    
    public void setApplicationContext(ApplicationContext applicationContext)
            throws BeansException {
        // TODO Auto-generated method stub
        this.applicationContext = applicationContext;
    }
    
    @RequestMapping("/index")
    public @ResponseBody String index() {
        logger.info(user.login("ddddd"));
        return "成功";
    }
    
    @RequestMapping("/merger")
    public @ResponseBody String merger() {
        //        logger.info(service.sayHello(""));
        for (String string : providerService.mergeArray()) {
            System.out.println(string);
        }
        for (String string : providerService.mergeList()) {
            System.out.println(string);
        }
        for (Map.Entry<String, String> entry : providerService.mergeMap()
                .entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            System.out.println(key + " " + value);
        }
        return "成功";
    }
    
    //    @RequestMapping("/login")
    //    public @ResponseBody String login() {
    //        logger.info(usrService.login(1, 2, "xxxd"));
    //        logger.info(usr2Service.login(1, 2, "xxxd"));
    //        return "成功";
    //    }
    //    
    @Autowired
    ValidationService validationService;
    
    @RequestMapping("/validation")
    public @ResponseBody String validation() {
        // Save OK
        ValidationParameter parameter = new ValidationParameter();
        parameter.setName("liangfei");
        parameter.setEmail("liangfei@liang.fei");
        parameter.setAge(50);
        parameter.setLoginDate(new Date(System.currentTimeMillis() - 1000000));
        parameter.setExpiryDate(new Date(System.currentTimeMillis() + 1000000));
        validationService.save(parameter);
        System.out.println("Validation Save OK");
        
        // Save Error
        try {
            parameter = new ValidationParameter();
            validationService.save(parameter);
            System.err.println("Validation Save ERROR");
        }
        catch (RpcException e) {
            ConstraintViolationException ve = (ConstraintViolationException)e.getCause();
            Set<ConstraintViolation<?>> violations = ve.getConstraintViolations();
            System.out.println(violations);
        }
        
        // Delete OK
        validationService.delete(2, "abc");
        System.out.println("Validation Delete OK");
        
        // Delete Error
        try {
            validationService.delete(0, "abc");
            System.err.println("Validation Delete ERROR");
        }
        catch (RpcException e) {
            ConstraintViolationException ve = (ConstraintViolationException)e.getCause();
            Set<ConstraintViolation<?>> violations = ve.getConstraintViolations();
            System.out.println(violations);
        }
        return "OK";
    }
    
    @Autowired
    CacheService cacheService;
    
    @RequestMapping("/cache")
    public @ResponseBody String cache() {
        // 测试缓存生效，多次调用返回同样的结果。(服务器端自增长返回值)
        String fix = null;
        for (int i = 0; i < 5; i++) {
            String result = cacheService.findCache("0");
            if (fix == null || fix.equals(result)) {
                System.out.println("OK: " + result);
            }
            else {
                System.err.println("ERROR: " + result);
            }
            fix = result;
            try {
                Thread.sleep(500);
            }
            catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        
        // LRU的缺省cache.size为1000，执行1001次，应有溢出
        for (int n = 0; n < 1001; n++) {
            String pre = null;
            for (int i = 0; i < 10; i++) {
                String result = cacheService.findCache(String.valueOf(n));
                if (pre != null && !pre.equals(result)) {
                    System.err.println("ERROR: " + result);
                }
                pre = result;
            }
        }
        
        // 测试LRU有移除最开始的一个缓存项
        String result = cacheService.findCache("0");
        if (fix != null && !fix.equals(result)) {
            System.out.println("OK: " + result);
        }
        else {
            System.err.println("ERROR: " + result);
        }
        return "OK";
    }
    
    @RequestMapping("/fanhua")
    public @ResponseBody String fanhuayinyong() {
        GenericService barService = (GenericService)applicationContext.getBean("userServixxxce3Impl");
        Object result = barService.$invoke("login",
                new String[] {"java.lang.String"},
                new Object[] {"World"});
        return "OK";
    }
    
    @RequestMapping("/fanhuashixian")
    public @ResponseBody String fanhuashixian() {
        GenericService barService = (GenericService)applicationContext.getBean("genericService");
        Object result = barService.$invoke("login",
                new String[] {"java.lang.String"},
                new Object[] {"World"});
        return "OK";
    }
    
    /** 
     * @Description 回声测试 
     * @param @return 参数 
     * @return String 返回类型  
     * @throws 
     */
    
    @RequestMapping("/huisheng")
    public @ResponseBody String huisheng() {
        Boolean bb = RpcContext.getContext().isConsumerSide();
        CacheService barService = (CacheService)applicationContext.getBean("cacheService");
        EchoService echoService = (EchoService)barService; // 强制转型为EchoService
        // 回声测试可用性
        String status = (String)echoService.$echo("OK");
        assert (status.equals("OK"));
        return "OK";
    }
    
    @Autowired
    AsyncService asyncService;
    
    @RequestMapping("/async")
    public @ResponseBody String async() {
        String result = asyncService.sayHello("jjjssack");
        System.out.println(result);
        // 拿到调用的Future引用，当结果返回后，会被通知和设置到此Future
        Future<String> fooFuture = RpcContext.getContext().getFuture();
        // 如果result已返回，直接拿到返回值，否则线程wait住，等待result返回后，线程会被notify唤醒
        try {
            result = fooFuture.get();
            System.out.println(result);
        }
        catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (ExecutionException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "OK";
    }
    
    @Autowired
    CallbackService callbackService;
    
    @RequestMapping("/callback")
    public @ResponseBody String callback() {
        callbackService.addListener("foo.bar", new CallbackListener() {
            public void changed(String msg) {
                System.out.println("callback1:" + msg);
            }
        });
        return "OK";
    }
    
    @Autowired
    Common common;
    
    @RequestMapping("/event")
    public @ResponseBody String event() {
        String result = common.eat("jdksk");
        System.out.println(result);
        // 拿到调用的Future引用，当结果返回后，会被通知和设置到此Future
        //        Future<String> fooFuture = RpcContext.getContext().getFuture();
        //        // 如果result已返回，直接拿到返回值，否则线程wait住，等待result返回后，线程会被notify唤醒
        //        try {
        //            result = fooFuture.get();
        //            System.out.println(result);
        //        }
        //        catch (InterruptedException e) {
        //            // TODO Auto-generated catch block
        //            e.printStackTrace();
        //        }
        //        catch (ExecutionException e) {
        //            // TODO Auto-generated catch block
        //            e.printStackTrace();
        //        }
        return "OK";
    }
    
    @Autowired
    StubService stub;
    
    @RequestMapping("/stub")
    public @ResponseBody String stub() {
        stub.stub("eee");
        return "OK";
    }
    
    @Autowired
    MockService mock;
    
    @RequestMapping("/mock")
    public @ResponseBody String mock() {
        mock.mock("vvvv");
        return "OK";
    }
    
    @Autowired
    @Qualifier("dubboTestServiceImpl1")
    DubboTestService dubboService1;
    
    @Autowired
    @Qualifier("dubboTestServiceImpl2")
    DubboTestService dubboService2;
    
    @RequestMapping("/dubboTest")
    public @ResponseBody String dubboTest() {
        dubboService1.eat("有人想害朕！");
        dubboService2.eat("有人想害朕！");
        return "dubboTest";
    }
    
    @Reference(check = false, timeout = 100000, version = "*")
    AnnotationDubboTest annotationdubbo;
    
    @RequestMapping("/annotationdubbo")
    public @ResponseBody String annotationdubbo() {
        annotationdubbo.eat("有人想害朕！");
        return "annotationdubbo";
    }
}
