package com.dongnao.jack.test;

import java.util.Date;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.dubbo.rpc.RpcException;
import com.dongnao.jack.service.ProviderService;
import com.dongnao.jack.service.UserService;
import com.dongnao.jack.service.ValidationParameter;
import com.dongnao.jack.service.ValidationService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:spring-dispatcher.xml")
public class MyTest implements ApplicationContextAware {
    
    ApplicationContext context;
    
    public void setApplicationContext(ApplicationContext arg0)
            throws BeansException {
        this.context = arg0;
        
    }
    
    @Test
    public void test() {
        ProviderService ps = (ProviderService)context.getBean("mergeUserService");
        for (String string : ps.mergeArray()) {
            System.out.println(string);
        }
        for (String string : ps.mergeList()) {
            System.out.println(string);
        }
        for (Map.Entry<String, String> entry : ps.mergeMap().entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            System.out.println(key + " " + value);
        }
    }
    
    @Autowired
    ValidationService validationService;
    
    @Test
    public void test1() {
        // Save OK
        ValidationParameter parameter = new ValidationParameter();
        parameter.setName("liangfei");
        parameter.setEmail("liangfei@liang.fei");
        parameter.setAge(50);
        parameter.setLoginDate(new Date(System.currentTimeMillis() - 1000000));
        parameter.setExpiryDate(new Date(System.currentTimeMillis() + 1000000));
        validationService.save(parameter);
        System.out.println("Validation Save OK");
        
        // Save Error
        try {
            parameter = new ValidationParameter();
            validationService.save(parameter);
            System.err.println("Validation Save ERROR");
        }
        catch (RpcException e) {
            ConstraintViolationException ve = (ConstraintViolationException)e.getCause();
            Set<ConstraintViolation<?>> violations = ve.getConstraintViolations();
            System.out.println(violations);
        }
        
        // Delete OK
        validationService.delete(2, "abc");
        System.out.println("Validation Delete OK");
        
        // Delete Error
        try {
            validationService.delete(0, "abc");
            System.err.println("Validation Delete ERROR");
        }
        catch (RpcException e) {
            ConstraintViolationException ve = (ConstraintViolationException)e.getCause();
            Set<ConstraintViolation<?>> violations = ve.getConstraintViolations();
            System.out.println(violations);
        }
    }
    
    @Test
    public void test2() {
        UserService user = context.getBean(UserService.class);
        System.out.println(user.login("dddd"));
    }
    
}
