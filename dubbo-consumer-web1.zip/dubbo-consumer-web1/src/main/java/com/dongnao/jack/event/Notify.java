package com.dongnao.jack.event;

public interface Notify {
    public void onreturn(String msg);
    
    public void onthrow(Throwable ex);
}
