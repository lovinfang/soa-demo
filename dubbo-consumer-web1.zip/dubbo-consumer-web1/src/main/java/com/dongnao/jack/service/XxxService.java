package com.dongnao.jack.service;

public interface XxxService {
    String xx(String param);
}
