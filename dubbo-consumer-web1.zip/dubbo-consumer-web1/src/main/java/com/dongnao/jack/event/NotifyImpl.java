package com.dongnao.jack.event;

public class NotifyImpl implements Notify {
    
    public void onreturn(String msg) {
        System.out.println("onreturn:" + msg);
    }
    
    public void onthrow(Throwable ex) {
        System.out.println("onreturn:" + ex);
        ex.printStackTrace();
    }
    
}
